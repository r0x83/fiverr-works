<?php session_start(); include('connect.php'); 

$from = $_GET['from'];
$operation = $_GET['operation'];

if ($from=='sigin' && $operation=='login') {
	$email = $_POST['email'];
	$pass = md5($_POST['pass']);
	$result = mysqli_query($con,"SELECT * FROM user WHERE email='$email' AND password='$pass'");
	if (mysqli_num_rows($result)>0) {
		$fetch = mysqli_fetch_array($result);
		$_SESSION['user_id'] = $fetch['id'];
		$_SESSION['email'] = $email;
		echo '1';
	}
	else {
		echo "0";
	}
}

if ($from=='sigup' && $operation=='register') {
	$type = $_POST['type'];
	$name = $_POST['name'];
	$email = $_POST['email'];
	$pass = md5($_POST['pass']);
	$telephone = $_POST['telephone'];
	$address = $_POST['address'];
	$result = mysqli_query($con,"SELECT * FROM user WHERE email='$email'");
	if (mysqli_num_rows($result)>0) {
		echo '0';
	}
	else {
		$result = mysqli_query($con,"INSERT INTO `user`(`name`,`email`, `password`, `address`, `phone`, `type`, `status`) VALUES ('$name','$email','$pass','$address','$telephone','$type','1')");
		echo '1';
	}
}

if ($from=='forgetPassword' && $operation=='resetPassword') {
	$email = $_POST['email'];
	$result = mysqli_query($con,"SELECT * FROM user WHERE email='$email'");
	if (mysqli_num_rows($result)>0) {
		$result2 = mysqli_query($con,"INSERT INTO `password_resets`(`email`) VALUES ('$email')");
		echo '1';
	}
	else {
		echo '0';
	}
}

if ($from=='provider' && $operation=='insert') {
	$wname = $_POST['wname'];
	$address = $_POST['address'];
	$city = $_POST['city'];
	$area = $_POST['area'];
	$warehouse_type = $_POST['warehouse_type'];
	$material_type = $_POST['material_type'];
	$storage_type = $_POST['storage_type'];
	$estimated_area = $_POST['estimated_area'];
	$price = $_POST['price'];

	$aa = $_GET['available_area'];
	$email = $_SESSION['email'];
	$user_id = $_SESSION['user_id'];
	
	$result2 = mysqli_query($con,"INSERT INTO `warehouse`(`user_id`, `name`, `city`, `address`, `warehouse_type`, `material_type`, `storage_type`, `total_area`, `estimated_area`, `price`, `available_area`, `status`) VALUES ('$user_id','$wname','$city','$address','$warehouse_type','$material_type','$storage_type','$area','$estimated_area','$price','$aa','1')");
	echo '1';
}

if ($from=='econtract' && $operation=='register') {
	$user_id = $_POST['user_id'];
	$warehouse_id = $_POST['warehouse_id'];
	$from = $_POST['from'];
	$to = $_POST['to'];
	$area = $_POST['area'];
	$price = $_POST['price'];
	$amount = $_POST['amount'];

	$result = mysqli_query($con,"INSERT INTO `warehouse_order`(`user_id`, `warehouse_id`, `from_date`, `to_date`, `required_area`, `price`,`amount`, `status`) VALUES ('$user_id','$warehouse_id','$from','$to','$area','$price','$amount','1')");
	if (mysqli_insert_id($con)>0) {
		echo '1';
	}
	else {
		echo '0';
	}
}
?>