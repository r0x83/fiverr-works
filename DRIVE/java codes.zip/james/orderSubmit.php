<?php include('session.php'); include('header.php'); include('connect.php'); ?>

<div class="container">
	<div class="alert alert-success">
		Order Submitted Successfully! Go to &#x2190; <a href="mainPage.php">Main Page</a>
	</div>
</div>

<?php include('footer.php'); ?>