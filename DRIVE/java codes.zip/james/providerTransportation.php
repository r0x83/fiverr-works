<?php include('session.php'); include('header.php'); include('connect.php'); 

$last_active_order = 0;
$result = mysqli_query($con,"SELECT warehouse_order.* FROM warehouse INNER JOIN warehouse_order ON warehouse.id=warehouse_order.warehouse_id WHERE warehouse.user_id='".$_SESSION['user_id']."' ORDER BY warehouse_order.id DESC");
while($fetch=mysqli_fetch_array($result)) {
	if ($fetch['status']==1) {
		$last_active_order = $fetch['required_area'];
		break;
	}
}
?>
<div class="container">
	<form method="POST" id="lockForm">
	<fieldset>
		<legend>User Provider Transportation</legend>
	<div class="row">
		<div class="col-md-12">
			<table align="center" width="40%">
				<tr>
					<td colspan="2">
						<div class="alert alert-danger visible-none" id="error"></div>
					</td>
				</tr>
				<tr>
					<td>From<span class="cl-red">*</span></td>
					<td><input type="text" name="wname" class="form-control" autocomplete="off" placeholder="Enter From Location" required><br></td>
				</tr>
				<tr>
					<td>To<span class="cl-red">*</span></td>
					<td><input type="text" name="address" class="form-control" autocomplete="off" placeholder="Enter To Location" required><br></td>
				</tr>
				<tr>
					<td>Packaging<span class="cl-red">*</span></td>
					<td><input type="text" name="city" class="form-control" autocomplete="off" placeholder="Enter Packaging" required><br></td>
				</tr>
				<tr>
					<td>No of Packages<span class="cl-red">*</span></td>
					<td><input type="number" name="area" id="area" class="form-control" autocomplete="off" placeholder="Enter No of Packages" required><br></td>
				</tr>
				<tr>
					<td>Weight Per Packages<span class="cl-red">*</span></td>
					<td><input type="number" name="area" id="area" class="form-control" autocomplete="off" placeholder="Enter Weight Per Packages" required><br></td>
				</tr>
				<tr>
					<td>Ship Date<span class="cl-red">*</span></td>
					<td><input type="date" name="area" id="area" class="form-control" autocomplete="off" placeholder="Enter Area sq.m" required><br></td>
				</tr>
				<tr>
					<td></td>
					<td><br><input type="button" id="sigin" class="btn btn-primary" value="Submit" style="width: 40%"/> <a href="mainPage.php" class="btn btn-info" style="width: 40%">Cancel</a>
					<input type="submit" id="submit-hidden" style="display: none;">
					<input type="reset" id="reset-hidden" style="display: none;">

					<input type="hidden" id="last_active_order" value="<?php echo $last_active_order; ?>"></td>
				</tr>
			</table>
		</div>
	</div>
	</fieldset>
	</form>
</div>
<br><br><br><br><br><br>
<?php include('footer.php'); ?>
<script type="text/javascript">

	$(document).ready(function () {
		$('#sigin').click(function () {
			if(!$("#lockForm")[0].checkValidity()){
				$("#lockForm").find("#submit-hidden").click();
			}
			else {
				var email = $('#email').val();
				var confirm_email = $('#confirm_email').val();
				if(email!=confirm_email){
					$('#error').attr('class','alert alert-danger');
				}
				else {
				var formData = new FormData($("#lockForm")[0]);
				var aa = $('#available_area').html();
				$.ajax({
			        url: "operation.php?from=providerTrans&operation=insert&available_area="+aa,
			        type: 'POST',
			        data: formData,
			        async: false,
			        success: function (info) {
				 		//alert(info);
				 		if(info==1){
				 			$('#error').html('Registerd successfully');
				 			$('#error').attr('class','alert alert-success');
				 			$("#lockForm").find("#reset-hidden").click();
				 		}
				 		else {
				 			$('#error').html('Try Again');
				 			$('#error').attr('class','alert alert-danger');
				 		}
			        },
			        cache: false,
			        contentType: false,
			        processData: false
			    });
				}
			}
		});

		$('#percentage').change(function () {
			var percentage = this.value.split("%");
			var area = $('#area').val();
			var lao = $('#last_active_order').val();
			var available_area = area-(area*(percentage[0]/100))-lao;
			$('#estimated_area').val(area*(percentage[0]/100));
			$('#available_area').html(available_area);
		});
	});

</script>

