<?php include('session.php');  include('header.php'); include('connect.php'); 
	
	$btnTxt1 = $btnTxt2 = $link = '';
	$result = mysqli_query($con,"SELECT * FROM user WHERE id='".$_SESSION['user_id']."'");
	$fetch = mysqli_fetch_array($result);
	if ($fetch['type']=='Individual') {
		$btnTxt1 = 'Request Warehouse';
		$btnTxt2 = 'Request Delivery';
		$link = 'requestWarehouse.php';
	}
	elseif ($fetch['type']=='Company') {
		$btnTxt1 = 'Provide Warehouse';
		$btnTxt2 = 'Provide Delivery';
		$link = 'providerWarehouse.php';
	}
?>

<div class="container">
	<form method="POST" id="lockForm">
	<fieldset>
		<legend><?php echo $fetch['type'] ?></legend>
	<div class="row">
		<div class="col-md-12">
			<table align="center" width="40%">
				<tr>
					<td colspan="2">
						<div class="alert alert-danger visible-none" id="error"></div>
					</td>
				</tr>
				<tr style="text-align: center;">
					<td></td>
					<td><a href="<?php echo $link; ?>" class="btn btn-primary" style="width: 50%"><?php echo $btnTxt1 ?></a></td>
				</tr>
				<tr style="text-align: center;">
					<td></td>
					<td><br><a href="#" class="btn btn-primary" style="width: 50%"><?php echo $btnTxt2 ?></a></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" id="submit-hidden" style="display: none;"></td>
				</tr>
			</table>
		</div>
	</div>
	</fieldset>
	</form>
</div>

<?php include('footer.php'); ?>
<script type="text/javascript">
	$(document).ready(function () {
		$('#sigin').click(function () {
			if(!$("#lockForm")[0].checkValidity()){
				$("#lockForm").find("#submit-hidden").click();
			}
			else {
				var formData = new FormData($("#lockForm")[0]);
				$.ajax({
			        url: "operation.php?from=sigin&operation=login",
			        type: 'POST',
			        data: formData,
			        async: false,
			        success: function (info) {
				 		//alert(info);
				 		if(info==1){
				 			// redirect to main page
				 		}
				 		else {
				 			$('#error').html('Email and Password are Invalid');
				 			$('#error').attr('class','alert alert-danger');
				 		}
			        },
			        cache: false,
			        contentType: false,
			        processData: false
			    });
			}
		});
	});
</script>