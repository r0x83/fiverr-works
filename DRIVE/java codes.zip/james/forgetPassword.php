<?php include('header.php'); include('connect.php'); ?>

<div class="container">
	<form method="POST" id="lockForm">
	<fieldset>
		<legend>Forget Password</legend>
	<div class="row">
		<div class="col-md-12">
			<table align="center" width="40%">
				<tr>
					<td colspan="2">
						<div class="alert alert-danger visible-none" id="error"></div>
					</td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input type="email" name="email" class="form-control" autocomplete="off" placeholder="Enter Email" required></td>
				</tr>
				<tr>
					<td></td>
					<td><br><input type="button" id="sigin" class="btn btn-primary" value="Send Request" style="width: 100%"/></td>
				</tr>
			</table>
		</div>
	</div>
	</fieldset>
	</form>
</div>

<?php include('footer.php'); ?>
<script type="text/javascript">
	$(document).ready(function () {
		$('#sigin').click(function () {
			if(!$("#lockForm")[0].checkValidity()){
				$("#lockForm").find("#submit-hidden").click();
			}
			else {
				var formData = new FormData($("#lockForm")[0]);
				$.ajax({
			        url: "operation.php?from=forgetPassword&operation=resetPassword",
			        type: 'POST',
			        data: formData,
			        async: false,
			        success: function (info) {
				 		//alert(info);
				 		if(info==1){
				 			$('#error').html('Request Submited');
				 			$('#error').attr('class','alert alert-success');
				 		}
				 		else {
				 			$('#error').html('Email not Exist');
				 			$('#error').attr('class','alert alert-danger');
				 		}
			        },
			        cache: false,
			        contentType: false,
			        processData: false
			    });
			}
		});
	});
</script>