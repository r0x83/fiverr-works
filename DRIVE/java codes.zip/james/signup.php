<?php //include('session.php'); 
include('header.php'); include('connect.php'); ?>

<div class="container">
	<form method="POST" id="lockForm">
	<fieldset>
		<legend>Signup</legend>
	<div class="row">
		<div class="col-md-12">
			<table align="center" width="40%">
				<tr>
					<td colspan="2">
						<div class="alert alert-danger visible-none" id="error">Email and Confirm Email not match</div>
					</td>
				</tr>
				<tr>
					<td>Type of user</td>
					<td><input type="radio" name="type" value="Individual" required> Individual &nbsp;&nbsp;&nbsp;<input type="radio" name="type" value="Company" required> Company</td>
				</tr>
				<tr>
					<td><br>Name</td>
					<td><br><input type="text" name="name" id="name" class="form-control" autocomplete="off" placeholder="Enter Name" required><br></td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input type="email" name="email" id="email" class="form-control" autocomplete="off" placeholder="Enter Email" required><br></td>
				</tr>
				<tr>
					<td>Confirm Email</td>
					<td><input type="email" name="confirm_email" id="confirm_email" class="form-control" autocomplete="off" placeholder="Enter Confirm Email" required><br></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><input type="password" name="pass" class="form-control" autocomplete="off" placeholder="Enter Password" required><br></td>
				</tr>
				<tr>
					<td>Telephone</td>
					<td><input type="number" name="telephone" id="telephone" class="form-control" autocomplete="off" placeholder="Enter Telephone Number" required><br></td>
				</tr>
				<tr>
					<td>Address</td>
					<td><input type="text" name="address" id="address" class="form-control" autocomplete="off" placeholder="Enter Address" required></td>
				</tr>
				<tr>
					<td></td>
					<td><br><input type="button" id="sigin" class="btn btn-primary" value="Submit" style="width: 40%"/> <a href="index.php" class="btn btn-info" style="width: 40%">Cancel</a>
					<input type="submit" id="submit-hidden" style="display: none;"></td>
				</tr>
			</table>
		</div>
	</div>
	</fieldset>
	</form>
</div>
<br><br><br>
<?php include('footer.php'); ?>
<script type="text/javascript">
	$(document).ready(function () {
		$('#sigin').click(function () {
			if(!$("#lockForm")[0].checkValidity()){
				$("#lockForm").find("#submit-hidden").click();
			}
			else {
				var email = $('#email').val();
				var confirm_email = $('#confirm_email').val();
				if(email!=confirm_email){
					$('#error').attr('class','alert alert-danger');
				}
				else {
				var formData = new FormData($("#lockForm")[0]);
				$.ajax({
			        url: "operation.php?from=sigup&operation=register",
			        type: 'POST',
			        data: formData,
			        async: false,
			        success: function (info) {
				 		//alert(info);
				 		if(info==1){
				 			$('#error').html('Registerd successfully Please go to login');
				 			$('#error').attr('class','alert alert-success');
				 		}
				 		else {
				 			$('#error').html('Email already taken, try with different email');
				 			$('#error').attr('class','alert alert-danger');
				 		}
			        },
			        cache: false,
			        contentType: false,
			        processData: false
			    });
				}
			}
		});
	});
</script>