<?php include('session.php'); include('header.php'); include('connect.php'); ?>

<div class="container">
	<form method="POST" action="search.php">
	<fieldset>
		<legend>User Request Warehouse</legend>
	<div class="row">
		<div class="col-md-12">
			<table align="center" width="40%">
				<tr>
					<td colspan="2">
						<div class="alert alert-danger visible-none" id="error"></div>
					</td>
				</tr>
				<tr>
					<td>Area Required<span class="cl-red">*</span></td>
					<td><input type="number" name="area" id="area" class="form-control" autocomplete="off" placeholder="Enter Area sq.m" required><br></td>
				</tr>
				<tr>
					<td colspan="2"><h4>* There is extra area added for utilities and other services</h4></td>
				</tr>
				<tr>
					<td><br>Type of Warehouse</td>
					<td><br><select name="warehouse_type" id="warehouse_type" class="form-control">
						<option value="0" disabled selected>--- Select ---</option>
						<option>DISTRIBUTION CENTER</option>
						<option>PICK, PACK, & SHIP</option>
						<option>SMART</option>
						<option>COLD STORAGE</option>
						<option>ON-DEMAND STORAGE</option>
						<option>BONDED WAREHOUSE</option>
					</select><br></td>
				</tr>
				<tr>
					<td>Type of Material</td>
					<td><select name="material_type" id="material_type" class="form-control">
						<option value="0" disabled selected>--- Select ---</option>
						<option>Electronics</option>
						<option>Mechanical</option>
						<option>Electrical</option>
					</select><br></td>
				</tr>
				<tr>
					<td>Type of Storage</td>
					<td><select name="storage_type" id="storage_type" class="form-control">
						<option value="0" disabled selected>--- Select ---</option>
						<option>Indoor</option>
						<option>Outdoor</option>
					</select><br></td>
				</tr>
				<tr>
					<td>Qty<span class="cl-red">*</span></td>
					<td><input type="number" name="qty" class="form-control" autocomplete="off" placeholder="Enter Qty" required><br></td>
				</tr>
				<tr>
					<td>Unit of Measure</td>
					<td><select name="unit_measure" id="unit_measure" class="form-control">
						<option value="0" disabled selected>--- Select ---</option>
						<option>Sq.m</option>
						<option>Inch</option>
					</select><br></td>
				</tr>
				<tr>
					<td colspan="2"><h4>Storage Period</h4></td>
				</tr>
				<tr>
					<td>From<span class="cl-red">*</span></td>
					<td><input type="date" name="from" class="form-control" required><br></td>
				</tr>
				<tr>
					<td>to<span class="cl-red">*</span></td>
					<td><input type="date" name="to" class="form-control" required></td>
				</tr>
				<tr>
					<td>Type of Packges</td>
					<td><br><select name="packges_type" id="packges_type" class="form-control">
						<option value="0" disabled selected>--- Select ---</option>
						<option>Paperboard boxes</option>
						<option>Corrugated boxes</option>
						<option>Plastic boxes</option>
						<option>Rigid boxes</option>
						<option>Chipboard packaging</option>
						<option>Poly bags</option>
						<option>Foil sealed bags</option>
					</select><br></td>
				</tr>
				<tr>
					<td>Remarks</td>
					<td><textarea name="remarks" class="form-control"></textarea><br></td>
				</tr>
				<tr>
					<td></td>
					<td><br><input type="submit" id="search" class="btn btn-primary" name="search" value="Search" style="width: 100%"/>
					<input type="submit" id="submit-hidden" style="display: none;"></td>
				</tr>
			</table>
		</div>
	</div>
	</fieldset>
	</form>
</div>
<br><br><br><br><br><br>

<?php include('footer.php'); ?>
<!-- <script type="text/javascript">
	$(document).ready(function () {
		$('#sigin').click(function () {
			if(!$("#lockForm")[0].checkValidity()){
				$("#lockForm").find("#submit-hidden").click();
			}
			else {
				var email = $('#email').val();
				var confirm_email = $('#confirm_email').val();
				if(email!=confirm_email){
					$('#error').attr('class','alert alert-danger');
				}
				else {
				var formData = new FormData($("#lockForm")[0]);
				$.ajax({
			        url: "operation.php?from=sigup&operation=register",
			        type: 'POST',
			        data: formData,
			        async: false,
			        success: function (info) {
				 		//alert(info);
				 		if(info==1){
				 			$('#error').html('Registerd successfully');
				 			$('#error').attr('class','alert alert-success');
				 		}
				 		else {
				 			$('#error').html('Email already taken, try with different email');
				 			$('#error').attr('class','alert alert-danger');
				 		}
			        },
			        cache: false,
			        contentType: false,
			        processData: false
			    });
				}
			}
		});
	});
</script> -->