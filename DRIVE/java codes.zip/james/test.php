<!DOCTYPE html>
<html>
<head>
	<title>Simple Map</title>
	<link rel="stylesheet" type="text/css" href="assets/css/custom.css">
	<script src="location.js"></script>
</head>
<body>
	<button onclick="getLoction()">Get Location</button>
	<div id="coords"></div>
	<input id="pac-input" type="text" placeholder="Search Box"
    />
	<div id="map"></div>
</body>
</html>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBRIX33jJ3sd_JXuUjpOlLiLTcfzwy6vH4&callback=initMap&libraries=&v=weekly" async></script>