let map, infoWindow, infoWindow2, lat1, lng1;
function initMap() {
  map = new google.maps.Map(document.getElementById("map"), {
    center: { lat: -34.397, lng: 150.644 },
    zoom: 13,
  });

  /* click listener get lat and lng */
  const coordsDiv = document.getElementById("coords");
  map.addListener("click", (event) => {
    coordsDiv.textContent =
      "lat: " +event.latLng.lat()+", " +"lng: " +
      event.latLng.lng();
    placeMarkerAndPanTo(event.latLng, map);
    msgWindow(event.latLng);
  });

  const input = document.getElementById("pac-input");
  const searchBox = new google.maps.places.SearchBox(input);
  map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
  map.addListener("bounds_changed", () => {
    searchBox.setBounds(map.getBounds());
  });
  
}

function msgWindow(latLng) {
  	infowindow2 = new google.maps.InfoWindow({
	    content: "Change the zoom level",
	    position: latLng,
  	});
  	infowindow2.close();
	infowindow2.open(map);
    infowindow2.setContent("Zoom:");
}
function placeMarkerAndPanTo(latLng, map) {
  new google.maps.Marker({
    position: latLng,
    map: map,
  });
  map.panTo(latLng);
}

function getLoction(argument) {
  infoWindow = new google.maps.InfoWindow();
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const pos = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          lat1 = position.coords.latitude;
          lng1 = position.coords.longitude;
          infoWindow.setPosition(pos);
          infoWindow.setContent(lat1+', '+lng1);
          infoWindow.open(map);
          map.setCenter(pos);
        },
        () => {
          handleLocationError(true, infoWindow, map.getCenter());
        }
      );
    } else {
      // Browser doesn't support Geolocation
      handleLocationError(false, infoWindow, map.getCenter());
    }
  }

function handleLocationError(browserHasGeolocation, infoWindow, pos) {
  infoWindow.setPosition(pos);
  infoWindow.setContent(
    browserHasGeolocation
      ? "Error: The Geolocation service failed."
      : "Error: Your browser doesn't support geolocation."
  );
  infoWindow.open(map);
}