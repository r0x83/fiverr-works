<?php include('session.php'); include('header.php'); include('connect.php');
error_reporting(0);
$area = $availableArea = $shownArea = $price = '--';
if (isset($_POST['search'])) {
	$area = $_POST['area'];
	$warehouse = $_POST['warehouse_type'];
	$material = $_POST['material_type'];
	$storage = $_POST['storage_type'];
	$unit = $_POST['unit_measure'];
	$qty = $_POST['qty'];
	$from = $_POST['from'];
	$to = $_POST['to'];
	$packges = $_POST['packges_type'];
	$remarks = $_POST['remarks'];
}
else {
	echo '<script type="text/javascript">window.location.href="mainPage.php";</script>';
}
?>
<div class="container">
	<form method="POST" id="lockForm">
	<fieldset>
		<legend>Search Results</legend>
	<div class="row">
		<div class="col-md-12">
			<?php 
			$sql = '';
				if ($area!='' && $warehouse=='' && $material=='' && $storage=='' && $packges=='') {
					$sql = "SELECT * FROM warehouse WHERE available_area>='$area' ORDER BY created_at";
				}
				elseif ($area!='' && $warehouse!='' && $material=='' && $storage=='' && $packges=='') {
					$sql = "SELECT * FROM warehouse WHERE available_area>='$area' AND warehouse_type='$warehouse' ORDER BY created_at";
				}
				elseif ($area!='' && $warehouse!='' && $material!='' && $storage=='' && $packges=='') {
					# code...
				}
				elseif ($area!='' && $warehouse!='' && $material!='' && $storage!='' && $packges=='') {
					$sql = "SELECT * FROM warehouse WHERE available_area>='$area' AND warehouse_type='$warehouse' AND material_type='$material' ORDER BY created_at";
				}
				elseif ($area!='' && $warehouse!='' && $material!='' && $storage!='' && $packges=='') {
					$sql = "SELECT * FROM warehouse WHERE available_area>='$area' AND warehouse_type='$warehouse' AND material_type='$material' AND storage_type='$storage' ORDER BY created_at";
				}
				elseif ($area!='' && $warehouse!='' && $material!='' && $storage!='' && $packges!='') {
					$sql = "SELECT * FROM warehouse WHERE available_area>='$area' AND warehouse_type='$warehouse' AND material_type='$material' AND storage_type='$storage' AND packges_type='$packges' ORDER BY created_at";
				}
				else {
					$sql = "SELECT * FROM warehouse WHERE available_area>='$area' ORDER BY created_at";
				}
				$result = mysqli_query($con,$sql);
				while($fetch=mysqli_fetch_array($result)) {
					$shownArea = $area+((($area/$fetch['available_area'])*100)*$area);
						$fromDay = explode('-', $from);
						$toDay = explode('-', $to);
						$numDays = abs($fromDay[2]-$toDay[2])+1;
						$price = $fetch['price']*$numDays*$shownArea;
			?>
			<table border="0" class="table-bordered" align="center" width="40%">
				
				<tr class="border-top border-left border-right">
					<td class="padding-l"><label>Name of Warehouse:</label></td>
					<td class="padding-l"><div id="warehouse_name"><?php echo $fetch['name'] ?></div></td>
					<td></td>
				</tr>
				<tr class="border-left border-right">
					<td class="padding-l"><label>City:</label></td>
					<td class="padding-l"><div id="city_name"><?php echo $fetch['city'] ?></div></td>
				</tr>
				<tr class="border-left border-right">
					<td class="padding-l" style="width: 40%"><label>Address:</label></td>
					<td class="padding-l"><div id="address_name"><?php echo $fetch['address'] ?></div></td>
				</tr>
				<tr class="border-left border-right">
					<td class="padding-l"><label>Available Area:</label></td>
					<td class="padding-l"><div id="shown_area"><?php echo $fetch['available_area']; ?></div></td>
				</tr>
				<tr class="border-left border-right">
					<td  class="padding-l"><label>Shown Area:</label></td>
					<td  class="padding-l"><div id="shown_area"><?php echo number_format($shownArea,2); ?></div></td>
				</tr>
				<tr class="border-left border-right">
					<td class="padding-l"><label>Price:</label></td>
					<td class="padding-l"><div id="price"><?php echo number_format($price,2); ?></div></td>
				</tr>
				<tr class="border-bottom border-left border-right align-center">
					<td class="padding" colspan="3"><br><a href="econtract.php?id=<?php echo $fetch['id'] ?>&from=<?php echo $from ?>&to=<?php echo $to ?>&price=<?php echo $price; ?>&area=<?php echo $area ?>" class="btn btn-primary" style="width: 50%"/>Choose</a></td>
				</tr>
			
			</table><br>
			<?php } ?>
		</div>
	</div>
	</fieldset>
	</form>
</div>
<br><br><br><br><br><br>

<?php include('footer.php'); ?>
<!-- <script type="text/javascript">
	$(document).ready(function () {
		$('#sigin').click(function () {
			if(!$("#lockForm")[0].checkValidity()){
				$("#lockForm").find("#submit-hidden").click();
			}
			else {
				var email = $('#email').val();
				var confirm_email = $('#confirm_email').val();
				if(email!=confirm_email){
					$('#error').attr('class','alert alert-danger');
				}
				else {
				var formData = new FormData($("#lockForm")[0]);
				$.ajax({
			        url: "operation.php?from=sigup&operation=register",
			        type: 'POST',
			        data: formData,
			        async: false,
			        success: function (info) {
				 		//alert(info);
				 		if(info==1){
				 			$('#error').html('Registerd successfully');
				 			$('#error').attr('class','alert alert-success');
				 		}
				 		else {
				 			$('#error').html('Email already taken, try with different email');
				 			$('#error').attr('class','alert alert-danger');
				 		}
			        },
			        cache: false,
			        contentType: false,
			        processData: false
			    });
				}
			}
		});
	});
</script> -->
<script
  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBRIX33jJ3sd_JXuUjpOlLiLTcfzwy6vH4&callback=initMap"
  async defer></script>
<script type="text/javascript">
var map;
function initMap() {
  var mapLayer = document.getElementById("map-layer");
  var centerCoordinates = new google.maps.LatLng(37.6, -95.665);
  var defaultOptions = { center: centerCoordinates, zoom: 4 }

  map = new google.maps.Map(mapLayer, defaultOptions);
}

function locate(){
  document.getElementById("btnAction").disabled = true;
  document.getElementById("btnAction").innerHTML = "Processing...";
  if ("geolocation" in navigator){
    navigator.geolocation.getCurrentPosition(function(position){ 
      var currentLatitude = position.coords.latitude;
      var currentLongitude = position.coords.longitude;

      var infoWindowHTML = "Latitude: " + currentLatitude + "<br>Longitude: " + currentLongitude;
      var infoWindow = new google.maps.InfoWindow({map: map, content: infoWindowHTML});
      var currentLocation = { lat: currentLatitude, lng: currentLongitude };
      infoWindow.setPosition(currentLocation);
      document.getElementById("btnAction").style.display = 'none';
    });
  }
}
</script>