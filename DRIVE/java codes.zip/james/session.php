<?php 
session_start();
if(!isset($_SESSION['email'])){
	echo '<script type="text/javascript">window.location.href="index.php"</script>';
}
?>

