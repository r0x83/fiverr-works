<?php include('header.php'); include('connect.php'); ?>

<div class="container">
	<form method="POST" id="lockForm">
	<fieldset>
		<legend>Signin</legend>
	<div class="row">
		<div class="col-md-12">
			<table align="center" width="40%">
				<tr>
					<td colspan="2">
						<div class="alert alert-danger visible-none" id="error"></div>
					</td>
				</tr>
				<tr>
					<td>Email</td>
					<td><input type="email" name="email" class="form-control" autocomplete="off" placeholder="Enter Email" required><br></td>
				</tr>
				<tr>
					<td>Password</td>
					<td><input type="password" name="pass" class="form-control" autocomplete="off" placeholder="Enter Password" required></td>
				</tr>
				<tr>
					<td></td>
					<td><a href="forgetPassword.php" class="pull-right">Forget You Password?</a></td>
				</tr>
				<tr>
					<td></td>
					<td><br><input type="button" id="sigin" class="btn btn-primary" value="Sigin" style="width: 100%"/></td>
				</tr>
				<tr>
					<td></td>
					<td style="text-align: center;"><br>Not Registered? <a href="signup.php">Signup</a>
						<input type="submit" id="submit-hidden" style="display: none;"></td>
				</tr>
			</table>
		</div>
	</div>
	</fieldset>
	</form>
</div>

<?php include('footer.php'); ?>
<script type="text/javascript">
	$(document).ready(function () {
		$('#sigin').click(function () {
			if(!$("#lockForm")[0].checkValidity()){
				$("#lockForm").find("#submit-hidden").click();
			}
			else {
				var formData = new FormData($("#lockForm")[0]);
				$.ajax({
			        url: "operation.php?from=sigin&operation=login",
			        type: 'POST',
			        data: formData,
			        async: false,
			        success: function (info) {
				 		//alert(info);
				 		if(info==1){
				 			window.location.href="mainPage.php";
				 		}
				 		else {
				 			$('#error').html('Email and Password are Invalid');
				 			$('#error').attr('class','alert alert-danger');
				 		}
			        },
			        cache: false,
			        contentType: false,
			        processData: false
			    });
			}
		});
	});
</script>