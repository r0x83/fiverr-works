<!DOCTYPE html>
<html>
  <head>
  <title>Add Map</title>
  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
  <style type="text/css">
    /* Set the size of the div element that contains the map */
    #map {
      height: 400px;
      /* The height is 400 pixels */
      width: 100%;
      /* The width is the width of the web page */
    }
  </style>
<script type="text/javascript">
let map, infoWindow, lat1, lng1;

function initMap() {
  map = new google.maps.Map(document.getElementById("map"), {
    center: { lat: -34.397, lng: 150.644 },
    zoom: 13,
  });
}

function getLoction(argument) {
  infoWindow = new google.maps.InfoWindow();
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const pos = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          lat1 = position.coords.latitude;
          lng1 = position.coords.longitude;
          infoWindow.setPosition(pos);
          infoWindow.setContent(lat1+', '+lng1);
          infoWindow.open(map);
          map.setCenter(pos);
        },
        () => {
          handleLocationError(true, infoWindow, map.getCenter());
        }
      );
    } else {
      // Browser doesn't support Geolocation
      handleLocationError(false, infoWindow, map.getCenter());
    }
  }

function handleLocationError(browserHasGeolocation, infoWindow, pos) {
  infoWindow.setPosition(pos);
  infoWindow.setContent(
    browserHasGeolocation
      ? "Error: The Geolocation service failed."
      : "Error: Your browser doesn't support geolocation."
  );
  infoWindow.open(map);
}
  </script>
  </head>
  <body>
    <h3>My Google Maps Demo</h3>
    <button onclick="getLoction()">Get Location</button>
    <!--The div element for the map -->
    <div id="map"></div>

    <!-- Async script executes immediately and must be after any DOM elements used in callback. -->
    <script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBRIX33jJ3sd_JXuUjpOlLiLTcfzwy6vH4&callback=initMap&libraries=&v=weekly"
      async
    ></script>
  </body>
</html>

<!-- <style>
#map-layer {
  margin: 20px 0px;
  max-width: 600px;
  min-height: 400;
}
#btnAction {
  background: #3878c7;
  padding: 10px 40px;
  border: #3672bb 1px solid;
  border-radius: 2px;
  color: #FFF;
  font-size: 0.9em;
  cursor:pointer;
  display:block;
}
#btnAction:disabled {
  background: #6c99d2;
}
</style>

<h1>How to Get Current Location using Google Map Javascript API</h1>
<div id="button-layer">
  <button id="btnAction" onClick="locate()">My Current Location</button>
</div>
<div id="map-layer"></div>
<script
  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBRIX33jJ3sd_JXuUjpOlLiLTcfzwy6vH4&callback=initMap"
  async defer></script>
<script type="text/javascript">
var map;
function initMap() {
  var mapLayer = document.getElementById("map-layer");
  var centerCoordinates = new google.maps.LatLng(37.6, -95.665);
  var defaultOptions = { center: centerCoordinates, zoom: 4 }

  map = new google.maps.Map(mapLayer, defaultOptions);
}

function locate(){
  document.getElementById("btnAction").disabled = true;
  document.getElementById("btnAction").innerHTML = "Processing...";
  if ("geolocation" in navigator){
    navigator.geolocation.getCurrentPosition(function(position){ 
      var currentLatitude = position.coords.latitude;
      var currentLongitude = position.coords.longitude;

      var infoWindowHTML = "Latitude: " + currentLatitude + "<br>Longitude: " + currentLongitude;
      var infoWindow = new google.maps.InfoWindow({map: map, content: infoWindowHTML});
      var currentLocation = { lat: currentLatitude, lng: currentLongitude };
      infoWindow.setPosition(currentLocation);
      document.getElementById("btnAction").style.display = 'none';
    });
  }
}
</script> -->

<!-- <script src="https://maps.googleapis.com/maps/api/js?libraries=geometry&key=AIzaSyBRIX33jJ3sd_JXuUjpOlLiLTcfzwy6vH4"></script>
<table border="1">
  <tr>
    <td>
      <div id="map" style="height: 600px; width:500px;"></div>
    </td>
    <td>
      <div id="side_bar"></div>
    </td>
  </tr>
</table>
<input id="address" type="text" value="Palo Alto, CA"></input>
<input type="button" value="Search" onclick="codeAddress();"></input>
<div id="info"></div>



<script type="text/javascript">
  var geocoder = null;
var map = null;
var customerMarker = null;
var gmarkers = [];
var closest = [];

function initialize() {
  // alert("init");
  geocoder = new google.maps.Geocoder();
  map = new google.maps.Map(document.getElementById('map'), {
    zoom: 9,
    center: new google.maps.LatLng(52.6699927, -0.7274620),
    mapTypeId: google.maps.MapTypeId.ROADMAP
  });
  var infowindow = new google.maps.InfoWindow();
  var marker, i;
  var bounds = new google.maps.LatLngBounds();
  document.getElementById('info').innerHTML = "found " + locations.length + " locations<br>";
  for (i = 0; i < locations.length; i++) {
    var coordStr = locations[i][4];
    var coords = coordStr.split(",");
    var pt = new google.maps.LatLng(parseFloat(coords[0]), parseFloat(coords[1]));
    bounds.extend(pt);
    marker = new google.maps.Marker({
      position: pt,
      map: map,
      icon: locations[i][5],
      address: locations[i][2],
      title: locations[i][0],
      html: locations[i][0] + "<br>" + locations[i][2]
    });
    gmarkers.push(marker);
    google.maps.event.addListener(marker, 'click', (function(marker, i) {
        return function() {
          infowindow.setContent(marker.html);
          infowindow.open(map, marker);
        }
      })
      (marker, i));
  }
  map.fitBounds(bounds);

}

function codeAddress() {
  var numberOfResults = 25;
  var numberOfDrivingResults = 5;
  var address = document.getElementById('address').value;
  geocoder.geocode({
    'address': address
  }, function(results, status) {
    if (status == google.maps.GeocoderStatus.OK) {
      map.setCenter(results[0].geometry.location);
      if (customerMarker) customerMarker.setMap(null);
      customerMarker = new google.maps.Marker({
        map: map,
        position: results[0].geometry.location
      });
      closest = findClosestN(results[0].geometry.location, numberOfResults);
      // get driving distance
      closest = closest.splice(0, numberOfResults);
      calculateDistances(results[0].geometry.location, closest, numberOfDrivingResults);
    } else {
      alert('Geocode was not successful for the following reason: ' + status);
    }
  });
}

function findClosestN(pt, numberOfResults) {
  var closest = [];
  document.getElementById('info').innerHTML += "processing " + gmarkers.length + "<br>";
  for (var i = 0; i < gmarkers.length; i++) {
    gmarkers[i].distance = google.maps.geometry.spherical.computeDistanceBetween(pt, gmarkers[i].getPosition());
    document.getElementById('info').innerHTML += "process " + i + ":" + gmarkers[i].getPosition().toUrlValue(6) + ":" + gmarkers[i].distance.toFixed(2) + "<br>";
    gmarkers[i].setMap(null);
    closest.push(gmarkers[i]);
  }
  closest.sort(sortByDist);
  return closest;
}

function sortByDist(a, b) {
  return (a.distance - b.distance)
}

function calculateDistances(pt, closest, numberOfResults) {
  var service = new google.maps.DistanceMatrixService();
  var request = {
    origins: [pt],
    destinations: [],
    travelMode: google.maps.TravelMode.DRIVING,
    unitSystem: google.maps.UnitSystem.METRIC,
    avoidHighways: false,
    avoidTolls: false
  };
  for (var i = 0; i < closest.length; i++) {
    request.destinations.push(closest[i].getPosition());
  }
  service.getDistanceMatrix(request, function(response, status) {
    if (status != google.maps.DistanceMatrixStatus.OK) {
      alert('Error was: ' + status);
    } else {
      var origins = response.originAddresses;
      var destinations = response.destinationAddresses;
      var outputDiv = document.getElementById('side_bar');
      outputDiv.innerHTML = '';

      var results = response.rows[0].elements;
      // save title and address in record for sorting
      for (var i = 0; i < closest.length; i++) {
        results[i].title = closest[i].title;
        results[i].address = closest[i].address;
        results[i].idx_closestMark = i;
      }
      results.sort(sortByDistDM);
      for (var i = 0;
        ((i < numberOfResults) && (i < closest.length)); i++) {
        closest[i].setMap(map);
        outputDiv.innerHTML += "<a href='javascript:google.maps.event.trigger(closest[" + results[i].idx_closestMark + "],\"click\");'>" + results[i].title + '</a><br>' + results[i].address + "<br>" + results[i].distance.text + ' appoximately ' + results[i].duration.text + '<br><hr>';
      }
    }
  });
}

function sortByDistDM(a, b) {
  return (a.distance.value - b.distance.value)
}

google.maps.event.addDomListener(window, 'load', initialize);
// Store Name[0],delivery[1],Address[2],Delivery Zone[3],Coordinates[4] data from FusionTables pizza stores example
var locations = [
  ["John's Pizza", "no", "400 University Ave, Palo Alto, CA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.121277,37.386799,0 -122.158012,37.4168,0 -122.158012,37.448151,0 -122.142906,37.456055,0 -122.118874,37.45224,0 -122.107544,37.437793,0 -122.102737,37.422526,0 -122.113037,37.414618,0 -122.121277,37.386799,0   </coordinates></LinearRing></outerBoundaryIs></Polygon>", "37.447038,-122.160575", "http://maps.google.com/mapfiles/ms/icons/blue.png"],
  ["JJs Express", "yes", "1000 Santa Cruz Ave, Menlo Park, CA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.200928,37.438611,0 -122.158012,37.4168,0 -122.158012,37.448151,0 -122.142906,37.456055,0 -122.144623,37.475948,0 -122.164192,37.481125,0 -122.189255,37.478673,0 -122.208481,37.468319,0 -122.201271,37.438338,0 </coordinates></LinearRing></outerBoundaryIs></Polygon>", "37.448638,-122.187176", "http://maps.google.com/mapfiles/ms/icons/green.png"],
  ["John Paul's Pizzeria", "no", "1100 El Camino Real, Belmont, CA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.304268,37.516534,0 -122.300835,37.505096,0 -122.262383,37.481669,0 -122.242813,37.502917,0 -122.244186,37.534232,0 -122.269249,37.550021,0 -122.291222,37.545122,0 -122.302895,37.537499,0 -122.304268,37.516534,0 </coordinates></LinearRing></outerBoundaryIs></Polygon>", "37.520436,-122.275978", "http://maps.google.com/mapfiles/ms/icons/red.png"],
  ["JJs Express", "yes", "300 E 4th Ave, San Mateo, CA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.304268,37.516534,0 -122.348557,37.538044,0 -122.359886,37.56363,0 -122.364006,37.582405,0 -122.33654,37.589207,0 -122.281609,37.570433,0 -122.291222,37.545122,0 -122.302895,37.537499,0 -122.304268,37.516534,0 </coordinates></LinearRing></outerBoundaryIs></Polygon>", "37.564435,-122.322080", "http://maps.google.com/mapfiles/ms/icons/green.png"],
  ["John's Pizza", "yes", "1400 Broadway Ave, Burlingame, CA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.374306,37.548933,0 -122.348557,37.538044,0 -122.359886,37.56363,0 -122.364006,37.582405,0 -122.33654,37.589207,0 -122.359543,37.59764,0 -122.372246,37.604712,0 -122.417564,37.594648,0 -122.374306,37.548933,0 </coordinates></LinearRing></outerBoundaryIs></Polygon>", "37.584935,-122.366182", "http://maps.google.com/mapfiles/ms/icons/blue.png"],
  ["JJs Express", "yes", "700 San Bruno Ave, San Bruno, CA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.462883,37.628916,0 -122.445374,37.639247,0 -122.426147,37.648762,0 -122.405205,37.642238,0 -122.400055,37.628644,0 -122.392159,37.610696,0 -122.372246,37.604712,0 -122.417564,37.594648,0 -122.462196,37.628644,0  </coordinates></LinearRing></outerBoundaryIs></Polygon>", "37.630934,-122.406883", "http://maps.google.com/mapfiles/ms/icons/green.png"],
  ["JJs Express", "yes", "300 Beach St, San Francisco, CA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.43576,37.790795,0 -122.449493,37.801646,0 -122.425461,37.809784,0 -122.402115,37.811411,0 -122.390442,37.794593,0 -122.408295,37.79188,0 -122.434387,37.789167,0 </coordinates></LinearRing></outerBoundaryIs></Polygon>", "37.807628,-122.413782", "http://maps.google.com/mapfiles/ms/icons/green.png"],
  ["JJs Express", "yes", "1400 Haight St, San Francisco, CA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.463398,37.760266,0 -122.477349,37.774785,0 -122.427349,37.774785,0 -122.429237,37.763658,0 -122.46357,37.760808,0</coordinates></LinearRing></outerBoundaryIs></Polygon>", "37.770129,-122.445082", "http://maps.google.com/mapfiles/ms/icons/green.png"],
  ["JJs Express", "yes", "2400 Mission St, San Francisco, CA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.418766,37.747779,0 -122.425289,37.768951,0 -122.406063,37.769901,0 -122.406063,37.749679,0 -122.418251,37.747508,0 </coordinates></LinearRing></outerBoundaryIs></Polygon>", "37.758630,-122.419082", "http://maps.google.com/mapfiles/ms/icons/green.png"],
  ["JJs Express", "yes", "500 Castro St, Mountain View, CA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.121277,37.386799,0 -122.108917,37.362244,0 -122.077675,37.3385,0 -122.064285,37.378615,0 -122.069778,37.3898,0 -122.076645,37.402619,0 -122.078705,37.411619,0 -122.113037,37.414618,0 -122.121277,37.386799,0  </coordinates></LinearRing></outerBoundaryIs></Polygon>", "37.390040,-122.081573", "http://maps.google.com/mapfiles/ms/icons/green.png"],
  ["John's Pizza", "no", "100 S Murphy Ave, Sunnyvale, CA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.047119,37.33113,0 -122.065315,37.332495,0 -122.077675,37.3385,0 -122.064285,37.378615,0 -122.036819,37.385162,0 -122.006607,37.382162,0 -122.00386,37.342048,0 -122.047119,37.331403,0  </coordinates></LinearRing></outerBoundaryIs></Polygon>", "37.377441,-122.030071", "http://maps.google.com/mapfiles/ms/icons/blue.png"],
  ["John's Pizza", "no", "1200 Curtner Ave, San Jose, CA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-121.935196,37.345051,0 -121.931076,37.294267,0 -121.871338,37.293721,0 -121.806793,37.293174,0 -121.798553,37.361426,0 -121.879578,37.36088,0 -121.934509,37.345597,0 -121.935196,37.345051,0 </coordinates></LinearRing></outerBoundaryIs></Polygon>", "37.288742,-121.890765", "http://maps.google.com/mapfiles/ms/icons/blue.png"],
  ["John's Pizza", "yes", "700 Blossom Hill Rd, San Jose, CA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-121.935883,37.253287,0 -121.931076,37.294267,0 -121.871338,37.293721,0 -121.806793,37.293174,0 -121.790657,37.234702,0 -121.852455,37.223221,0 -121.935539,37.253014,0 </coordinates></LinearRing></outerBoundaryIs></Polygon>", "37.250543,-121.846563", "http://maps.google.com/mapfiles/ms/icons/blue.png"],
  ["John's Pizza", "yes", "100 N Milpitas Blvd, Milpitas, CA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-121.947556,37.435612,0 -121.934509,37.476493,0 -121.893311,37.469409,0 -121.852798,37.429615,0 -121.843872,37.400165,0 -121.887817,37.3898,0 -121.959915,37.420345,0 -121.959915,37.427979,0 -121.948929,37.435612,0 -121.947556,37.435612,0</coordinates></LinearRing></outerBoundaryIs></Polygon>", "37.434113,-121.901139", "http://maps.google.com/mapfiles/ms/icons/blue.png"],
  ["John's Pizza", "yes", "3300 Mowry Blvd, Fremont, CA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.02343,37.52198,0 -122.023773,37.558731,0 -121.989784,37.573426,0 -121.959572,37.566351,0 -121.944466,37.544305,0 -121.967125,37.520891,0 -122.023087,37.522525,0</coordinates></LinearRing></outerBoundaryIs></Polygon>", "37.552773,-121.985153", "http://maps.google.com/mapfiles/ms/icons/blue.png"],
  //New York, NY, USA (40.7127837, -74.00594130000002)  
  ["New York, NY, USA", "no", "New York City Hall, New York, NY 10007, USA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.02343,37.52198,0 -122.023773,37.558731,0 -121.989784,37.573426,0 -121.959572,37.566351,0 -121.944466,37.544305,0 -121.967125,37.520891,0 -122.023087,37.522525,0</coordinates></LinearRing></outerBoundaryIs></Polygon>", "40.7127837, -74.0059413", "http://maps.google.com/mapfiles/ms/icons/yellow.png"],
  // Newark, NJ, USA (40.735657, -74.1723667)  
  ["Newark, NJ, USA", "no", "169 Market St, Newark, NJ 07102, USA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.02343,37.52198,0 -122.023773,37.558731,0 -121.989784,37.573426,0 -121.959572,37.566351,0 -121.944466,37.544305,0 -121.967125,37.520891,0 -122.023087,37.522525,0</coordinates></LinearRing></outerBoundaryIs></Polygon>", "40.735657, -74.1723667", "http://maps.google.com/mapfiles/ms/icons/yellow.png"],
  // Baltimore, MD, USA (39.2903848, -76.6121893
  ["Baltimore, MD, USA", "no", "201-211 E Fayette St, Baltimore, MD 21202, USA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.02343,37.52198,0 -122.023773,37.558731,0 -121.989784,37.573426,0 -121.959572,37.566351,0 -121.944466,37.544305,0 -121.967125,37.520891,0 -122.023087,37.522525,0</coordinates></LinearRing></outerBoundaryIs></Polygon>", "39.2903848, -76.6121893", "http://maps.google.com/mapfiles/ms/icons/yellow.png"],
  // Boston, MA, USA (42.3600825, -71.05888
  ["Boston, MA, USA", "no", "City Hall Plaza, Boston, MA 02203, USA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.02343,37.52198,0 -122.023773,37.558731,0 -121.989784,37.573426,0 -121.959572,37.566351,0 -121.944466,37.544305,0 -121.967125,37.520891,0 -122.023087,37.522525,0</coordinates></LinearRing></outerBoundaryIs></Polygon>", "42.3600825, -71.05888", "http://maps.google.com/mapfiles/ms/icons/yellow.png"],
  // Philadelphia, PA, USA (39.9525839, -75.16522150000003)
  ["Philadelphia, PA, USA", "no", "1414 PA-611, Philadelphia, PA 19102, USA", "<Polygon><outerBoundaryIs><LinearRing><coordinates>-122.02343,37.52198,0 -122.023773,37.558731,0 -121.989784,37.573426,0 -121.959572,37.566351,0 -121.944466,37.544305,0 -121.967125,37.520891,0 -122.023087,37.522525,0</coordinates></LinearRing></outerBoundaryIs></Polygon>", "39.9525839, -75.1652215", "http://maps.google.com/mapfiles/ms/icons/yellow.png"]
];
</script> 
 -->

 <!-- provider data -->

<!--  <?php include('session.php'); include('header.php'); include('connect.php'); 

$last_active_order = 0;
$result = mysqli_query($con,"SELECT warehouse_order.* FROM warehouse INNER JOIN warehouse_order ON warehouse.id=warehouse_order.warehouse_id WHERE warehouse.user_id='".$_SESSION['user_id']."' ORDER BY warehouse_order.id DESC");
while($fetch=mysqli_fetch_array($result)) {
  if ($fetch['status']==1) {
    $last_active_order = $fetch['required_area'];
    break;
  }
}
?>
<style type="text/css">
#map-layer {
  margin: 20px 0px;
  max-width: 600px;
  min-height: 400;
}
#btnAction {
  background: #3878c7;
  padding: 10px 40px;
  border: #3672bb 1px solid;
  border-radius: 2px;
  color: #FFF;
  font-size: 0.9em;
  cursor:pointer;
  display:block;
}
#btnAction:disabled {
  background: #6c99d2;
}
</style>
<div class="container">
  <form method="POST" id="lockForm">
  <fieldset>
    <legend>User Provider Warehouse</legend>
  <div class="row">
    <div class="col-md-12">
      <table align="center" width="40%">
        <tr>
          <td colspan="2">
            <div class="alert alert-danger visible-none" id="error"></div>
          </td>
        </tr>
        <tr>
          <td><button type="button" class="" data-toggle="modal" data-target="#myModal">Get My Location</button>
          <td><div id="latlng">--</div></td><br></td>
        </tr>
        <tr>
          <td>Total Area of Warehouse</td>
          <td><input type="number" name="area" id="area" class="form-control" autocomplete="off" placeholder="Enter Area sq.m"><br></td>
        </tr>
        <tr>
          <td colspan="2"><h4>Common Area</h4></td>
        </tr>
        <tr>
          <td>Percentage</td>
          <td><select name="percentage" id="percentage" class="form-control">
            <option value="0" disabled selected>--- Select ---</option>
            <option>10%</option>
            <option>20%</option>
            <option>25%</option>
          </select><br></td>
        </tr>
        <tr>
          <td>Estimated Area</td>
          <td><input type="number" name="estimated_area" id="estimated_area" class="form-control" autocomplete="off" placeholder="Enter Estimated Area" readonly></td>
        </tr>
        <tr>
          <td>Price/Sq.m (SAR)</td>
          <td><br><input type="number" name="price" class="form-control" autocomplete="off" placeholder="Enter Price"><br></td>
        </tr>
        <tr>
          <td>Available Area</td>
          <td><br><div id="available_area">--</div><br></td>
        </tr>
        <tr>
          <td></td>
          <td><br><input type="button" id="sigin" class="btn btn-primary" value="Submit" style="width: 40%"/> <a href="mainPage.php" class="btn btn-info" style="width: 40%">Cancel</a>
          <input type="submit" id="submit-hidden" style="display: none;">

          <input type="hidden" id="last_active_order" value="<?php echo $last_active_order; ?>"></td>
        </tr>
      </table>
    </div>
  </div>
  </fieldset>
  </form>
</div>
<br><br><br><br><br><br>
Modal 
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    Modal content
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">My Current Location</h4>
      </div>
      <div class="modal-body">
        <button class="btn btn-primary" onclick="getLoction()">Get Location</button>
        <button class="btn btn-primary" onclick="getlatlng()" data-dismiss="modal">Submit</button>
        <hr>
        <div id="map"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<?php include('footer.php'); ?>
<script type="text/javascript">

  $(document).ready(function () {
    $('#sigin').click(function () {
      if(!$("#lockForm")[0].checkValidity()){
        $("#lockForm").find("#submit-hidden").click();
      }
      else {
        var email = $('#email').val();
        var confirm_email = $('#confirm_email').val();
        if(email!=confirm_email){
          $('#error').attr('class','alert alert-danger');
        }
        else {
        var formData = new FormData($("#lockForm")[0]);
        var aa = $('#available_area').html();
        $.ajax({
              url: "operation.php?from=provider&operation=insert&available_area="+aa,
              type: 'POST',
              data: formData,
              async: false,
              success: function (info) {
            //alert(info);
            if(info==1){
              $('#error').html('Registerd successfully');
              $('#error').attr('class','alert alert-success');
            }
            else {
              $('#error').html('Try Again');
              $('#error').attr('class','alert alert-danger');
            }
              },
              cache: false,
              contentType: false,
              processData: false
          });
        }
      }
    });

    $('#percentage').change(function () {
      var percentage = this.value.split("%");
      var area = $('#area').val();
      var lao = $('#last_active_order').val();
      var available_area = area-(area*(percentage[0]/100))-lao;
      $('#estimated_area').val(area*(percentage[0]/100));
      $('#available_area').html(available_area);
    });
  });

</script>
<script
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBRIX33jJ3sd_JXuUjpOlLiLTcfzwy6vH4&callback=initMap&libraries=&v=weekly"
      async
    ></script>
<script type="text/javascript">
let map, infoWindow, lat1, lng1;

function initMap() {
  map = new google.maps.Map(document.getElementById("map"), {
    center: { lat: -34.397, lng: 150.644 },
    zoom: 13,
  });
}

function getLoction(argument) {
  infoWindow = new google.maps.InfoWindow();
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const pos = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          };
          lat1 = position.coords.latitude;
          lng1 = position.coords.longitude;
          infoWindow.setPosition(pos);
          infoWindow.setContent(lat1+', '+lng1);
          infoWindow.open(map);
          map.setCenter(pos);
        },
        () => {
          handleLocationError(true, infoWindow, map.getCenter());
        }
      );
    } else {
      // Browser doesn't support Geolocation
      handleLocationError(false, infoWindow, map.getCenter());
    }
  }

function handleLocationError(browserHasGeolocation, infoWindow, pos) {
  infoWindow.setPosition(pos);
  infoWindow.setContent(
    browserHasGeolocation
      ? "Error: The Geolocation service failed."
      : "Error: Your browser doesn't support geolocation."
  );
  infoWindow.open(map);
}

function getlatlng(argument) {
  $('#latlng').html('Your Postion: 'lat1+', '+lng1);
}
</script>

 -->


 <!-- search page data -->
 <!-- 
<script type="text/javascript" src="location.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?libraries=geometry&key=AIzaSyCkUOdZ5y7hMm0yrcCQoCvLwzdM6M8s5qk"></script>
<?php include('session.php'); include('header.php'); include('connect.php');
$area = $availableArea = $shownArea = $price = '--';
if (isset($_POST['search'])) {
  $area = $_POST['area'];
  $warehouse = $_POST['warehouse_type'];
  $material = $_POST['material_type'];
  $storage = $_POST['storage_type'];
  $unit = $_POST['unit_measure'];
  $qty = $_POST['qty'];
  $from = $_POST['from'];
  $to = $_POST['to'];
  $packges = $_POST['packges_type'];
  $remarks = $_POST['remarks'];
}
else {
  echo '<script type="text/javascript">window.location.href="mainPage.php";</script>';
}
?>
<style>
#map-layer {
  margin: 20px 0px;
  max-width: 600px;
  min-height: 400;
}
#btnAction {
  background: #3878c7;
  padding: 10px 40px;
  border: #3672bb 1px solid;
  border-radius: 2px;
  color: #FFF;
  font-size: 0.9em;
  cursor:pointer;
  display:block;
}
#btnAction:disabled {
  background: #6c99d2;
}
</style>
<div class="container">
  <form method="POST" id="lockForm">
  <fieldset>
    <legend>Results</legend>
  <div class="row">
    <div class="col-md-12">
      <?php 
        $result = mysqli_query($con,"SELECT * FROM warehouse WHERE available_area>='$area'");
        while($fetch=mysqli_fetch_array($result)) {
          $shownArea = $area+((($area/$fetch['available_area'])*100)*$area);
            $fromDay = explode('-', $from);
            $toDay = explode('-', $to);
            $numDays = abs($fromDay[2]-$toDay[2])+1;
            $price = $fetch['price']*$numDays*$shownArea;
      ?>
      <table border="0" class="table-bordered" align="center" width="40%">
        
        <tr class="border-top border-left border-right">
          <td class="padding-l"><label>Name of Warehouse:</label></td>
          <td class="padding-l"><div id="warehouse_name">--</div></td>
          <td rowspan="6" class="padding"><div id="map-layer">Map</div></td>
        </tr>
        <tr class="border-left border-right">
          <td class="padding-l"><label>City:</label></td>
          <td class="padding-l"><div id="city_name">--</div></td>
        </tr>
        <tr class="border-left border-right">
          <td class="padding-l"><label>Address:</label></td>
          <td class="padding-l"><div id="address_name">--</div></td>
        </tr>
        <tr class="border-left border-right">
          <td class="padding-l"><label>Available Area:</label></td>
          <td class="padding-l"><div id="shown_area"><?php echo $fetch['available_area']; ?></div></td>
        </tr>
        <tr class="border-left border-right">
          <td  class="padding-l"><label>Shown Area:</label></td>
          <td  class="padding-l"><div id="shown_area"><?php echo number_format($shownArea,2); ?></div></td>
        </tr>
        <tr class="border-left border-right">
          <td class="padding-l"><label>Price:</label></td>
          <td class="padding-l"><div id="price"><?php echo number_format($price,2); ?></div></td>
        </tr>
        <tr class="border-bottom border-left border-right align-center">
          <td class="padding" colspan="3"><br><a href="econtract.php?id=<?php echo $fetch['id'] ?>&from=<?php echo $from ?>&to=<?php echo $to ?>&price=<?php echo $price; ?>&area=<?php echo $area ?>" class="btn btn-primary" style="width: 50%"/>Choose</a></td>
        </tr>
      
      </table><br>
      <?php } ?>
    </div>
  </div>
  </fieldset>
  </form>
</div>
<br><br><br><br><br><br>

<?php include('footer.php'); ?>
 <script type="text/javascript">
  $(document).ready(function () {
    $('#sigin').click(function () {
      if(!$("#lockForm")[0].checkValidity()){
        $("#lockForm").find("#submit-hidden").click();
      }
      else {
        var email = $('#email').val();
        var confirm_email = $('#confirm_email').val();
        if(email!=confirm_email){
          $('#error').attr('class','alert alert-danger');
        }
        else {
        var formData = new FormData($("#lockForm")[0]);
        $.ajax({
              url: "operation.php?from=sigup&operation=register",
              type: 'POST',
              data: formData,
              async: false,
              success: function (info) {
            //alert(info);
            if(info==1){
              $('#error').html('Registerd successfully');
              $('#error').attr('class','alert alert-success');
            }
            else {
              $('#error').html('Email already taken, try with different email');
              $('#error').attr('class','alert alert-danger');
            }
              },
              cache: false,
              contentType: false,
              processData: false
          });
        }
      }
    });
  });
</script> 
<script
  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBRIX33jJ3sd_JXuUjpOlLiLTcfzwy6vH4&callback=initMap"
  async defer></script>
<script type="text/javascript">
var map;
function initMap() {
  var mapLayer = document.getElementById("map-layer");
  var centerCoordinates = new google.maps.LatLng(37.6, -95.665);
  var defaultOptions = { center: centerCoordinates, zoom: 4 }

  map = new google.maps.Map(mapLayer, defaultOptions);
}

function locate(){
  document.getElementById("btnAction").disabled = true;
  document.getElementById("btnAction").innerHTML = "Processing...";
  if ("geolocation" in navigator){
    navigator.geolocation.getCurrentPosition(function(position){ 
      var currentLatitude = position.coords.latitude;
      var currentLongitude = position.coords.longitude;

      var infoWindowHTML = "Latitude: " + currentLatitude + "<br>Longitude: " + currentLongitude;
      var infoWindow = new google.maps.InfoWindow({map: map, content: infoWindowHTML});
      var currentLocation = { lat: currentLatitude, lng: currentLongitude };
      infoWindow.setPosition(currentLocation);
      document.getElementById("btnAction").style.display = 'none';
    });
  }
}
</script>

  -->