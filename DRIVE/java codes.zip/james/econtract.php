<?php include('session.php'); include('header.php'); include('connect.php');
$fromDate = $toDate = $Sellername = $Buyername = $Selleraddress = $Buyeraddress = $Sellerphone = $Buyerphone = '--';
$price = $amount = $area = $Buyerid = $id = 0;
if (isset($_GET['id'])) {
	$id = $_GET['id'];
	$result = mysqli_query($con,"SELECT warehouse.*, user.* FROM warehouse INNER JOIN user ON warehouse.user_id=user.id WHERE warehouse.id='$id'");
	$fetch = mysqli_fetch_array($result);
	$result2 = mysqli_query($con,"SELECT * FROM user WHERE email='".$_SESSION['email']."'");
	$fetch2 = mysqli_fetch_array($result2);
	$fromDate = $_GET['from'];
	$toDate = $_GET['to'];
	$Sellername = $fetch['name'];
	$Selleraddress = $fetch['address'];
	$Sellerphone = $fetch['phone'];
	$Buyername = $fetch2['name'];
	$Buyeraddress = $fetch2['address'];
	$Buyerphone = $fetch2['phone'];
	$Buyerid = $fetch2['id'];
	$price = $fetch['price'];
	$amount = $_GET['price'];
	$area = $_GET['area'];
}

?>

<div class="container">
	<div class="row">
		<div class="col-md-12" id="printable">
			<table border="0" width="100%" class="border-top">
				<tr class="bg-blue cl-white">
					<td class="padding" colspan="2">&nbsp;</td>
				</tr>
			</table>
			<table border="0" width="90%" align="center">
				
				<tr>
					<td class="padding align-center"><h3>Warehouse Rental Contract</h3></td>
					<td class="padding align-center"><img src="assets/img/m_11.jpg" width="80"></td>
				</tr>
				<tr>
					<td></td>
					<td class="align-center font-size"><?php echo date('D, M d, Y',strtotime($fromDate)); ?></td>
				</tr>
				<tr class="">
					<td class="padding" colspan="2">&nbsp;</td>
				</tr>
				<tr class="bg-blue cl-white">
					<td class="padding" colspan="2"><label>This rental agreement is executed on <?php echo date('D, M d, Y',strtotime($fromDate)); ?>, by and between the following parties:</label></td>
				</tr>
				<tr>
					<td class="padding-l font-size"><br><label>Seller</label></td>
					<td class="padding-l font-size"><br><label>Name of Buyer</label></td>
				</tr>
				<tr>
					<td class="padding-l font-size"><?php echo $Sellername; ?></td>
					<td class="padding-l font-size"><?php echo $Buyername; ?></td>
				</tr>
				<tr>
					<td class="padding-l font-size"><label>Phone of Seller</label></td>
					<td class="padding-l font-size"><label>Phone of Buyer</label></td>
				</tr>
				<tr>
					<td class="padding-l font-size"><?php echo $Sellerphone; ?></td>
					<td class="padding-l font-size"><?php echo $Buyerphone; ?></td>
				</tr>
				<tr>
					<td class="padding-l font-size"><label>Address of Seller</label></td>
					<td class="padding-l font-size"><label>Address of Buyer</label></td>
				</tr>
				<tr>
					<td class="padding-l font-size"><?php echo $Selleraddress; ?></td>
					<td class="padding-l font-size"><?php echo $Buyeraddress; ?></td>
				</tr>
				<tr class="">
					<td class="padding" colspan="2">&nbsp;</td>
				</tr>
				<tr class="bg-blue cl-white">
					<td class="padding" colspan="2"><label>Description of the Property</label></td>
				</tr>
				<tr>
					<td class="padding-l font-size" colspan="2">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</td>
				</tr>
				<tr class="">
					<td class="padding font-size" colspan="2">&nbsp;</td>
				</tr>
				<tr class="bg-blue cl-white">
					<td class="padding" colspan="2"><label>Payment and Transaction of Ownership Terms</label></td>
				</tr>
				<tr>
					<td class="padding-l font-size"><br><label>Seller Price</label></td>
					<td class="padding-l font-size"><br><label>Rental Amount</label></td>
				</tr>
				<tr>
					<td class="padding-l font-size"><?php echo number_format($price,2); ?></td>
					<td class="padding-l font-size"><?php echo number_format($amount,2); ?></td>
				</tr>
				<tr>
					<td class="padding-l font-size"><label>Given Area</label></td>
					<td class="padding-l font-size"><label>Required Area</label></td>
				</tr>
				<tr>
					<td class="padding-l font-size"><?php echo number_format($area,2); ?></td>
					<td class="padding-l font-size"><?php echo number_format($area,2); ?></td>
				</tr>
				<tr>
					<td class="padding-l font-size"><label>Duration of Rent</label></td>
					<td class="padding-l font-size"><label>Payment Term</label></td>
				</tr>
				<tr>
					<td class="padding-l font-size"><?php echo date('d-m-Y',strtotime($fromDate))." to ".date('d-m-Y',strtotime($toDate)); ?></td>
					<td class="padding-l font-size">Cash</td>
				</tr>

				<tr>
					<td class="padding-l font-size"><br><br><br><br><label>_____________________</label></td>
					<td class="padding-l font-size"><br><br><br><br><label>_____________________</label></td>
				</tr>
				<tr>
					<td class="padding-l font-size">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Owner Signature</td>
					<td class="padding-l font-size">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Buyer Signature</td>
				</tr>
			</table>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<table width="90%" align="center">
				<form method="POST" id="lockForm">
				<tr>
				<td><hr><input type="button" id="sigin" class="btn btn-primary" value="Submit" style="width: 20%" />

				<input type="hidden" name="user_id" value="<?php echo $Buyerid ?>"/>
				<input type="hidden" name="warehouse_id" value="<?php echo $id ?>"/>
				<input type="hidden" name="from" value="<?php echo $fromDate ?>"/>
				<input type="hidden" name="to" value="<?php echo $toDate ?>"/>
				<input type="hidden" name="area" value="<?php echo $area ?>"/>
				<input type="hidden" name="price" value="<?php echo $price ?>"/>
				<input type="hidden" name="amount" value="<?php echo $amount ?>"/>
				</td>
				</tr>
				</form>
			</table>
		</div>
	</div>
</div>
<br><br><br><br>
<?php include('footer.php'); ?>
<script type="text/javascript">

	$('.jumbotron').css('display','none');
	$('.navbar').css('display','none');

	function printDiv(divName) {
	    var printContents = document.getElementById(divName).innerHTML;
	    var originalContents = document.body.innerHTML;
	    document.body.innerHTML = printContents;
	    window.print();
	    document.body.innerHTML = originalContents;
	}

	$(document).ready(function () {
		$('#sigin').click(function () {
			var formData = new FormData($("#lockForm")[0]);
			$.ajax({
		        url: "operation.php?from=econtract&operation=register",
		        type: 'POST',
		        data: formData,
		        async: false,
		        success: function (info) {
			 		//alert(info);
			 		if(info==1){
			 			printDiv('printable');
			 			setTimeout(function(){ 
			 				window.location.href="orderSubmit.php"; 
			 			},2000);
			 		}
			 		else {
			 			alert('Something went wrong');
			 		}
		        },
		        cache: false,
		        contentType: false,
		        processData: false
		    });
		});
	});
</script>