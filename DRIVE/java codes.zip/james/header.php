<!DOCTYPE html>
<html>
<head>
	<title>App</title>
	<link rel="stylesheet" type="text/css" href="assets/css/custom.css">
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">
	<script type="text/javascript" src="assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
</head>
<body>
	<!-- <div class="jumbotron">
		<a href="index.php">Signin</a> |
		<a href="signup.php">Signup</a> |
		<a href="forgetPassword.php">Forget Password</a> |
		<a href="mainPage.php">Main Page</a> | 
		<a href="requestWarehouse.php">Request Warehouse</a> |
		<a href="providerWarehouse.php">Provider Warehouse</a> |
		<a href="search.php">Search</a> |
		<a href="econtract.php">E-Contract</a>
	</div> -->
	<div class="jumbotron" style="margin-bottom: 0px;"></div>
	<nav class="navbar navbar-default">
	  <div class="container-fluid">
	    <div class="navbar-header">
	      <a class="navbar-brand" href="#">James</a>
	    </div>
	    <ul class="nav navbar-nav">
	      <li class="active"><a href="index.php">Signin</a></li>
	      <li><a href="mainPage.php">Main Page</a></li>
	      <li><a href="requestWarehouse.php">Request Warehouse</a></li>
	      <li><a href="providerWarehouse.php">Provider Warehouse</a></li>
	      <li><a href="requestTransportation.php">Request Transportation</a></li>
	      <li><a href="providerTransportation.php">Provider Transportation</a></li>
	      <li><a href="search.php">Search</a></li>
	      <li><a href="econtract.php">E-Contract</a></li>
	    </ul>
	    <ul class="nav navbar-nav navbar-right">
	      <li><a href="logout.php">Logout</a></li>
	    </ul>
	  </div>
	</nav><br>

